var InvocationTest = new Class
({
	Extends: PyrTestCase

	,name: "InvocationTest"

	,soma: null

	,stage:null

	,somaViewTestObj: null

	,domtreeTestNode: null

	,spriteTestAccess:null

	,executed: false

	,executedCount: 0

	,userAccessFromInstance: false

	,userAccessFromInstanceCount:0

	,userAccessFromDisplayList: false

	,setUserAccessFromDisplayListBound:null

	,setUserAccessFromInstanceBound: null

	,cancelEventBound: null

	,initialize: function()
	{
		this.cancelEventBound = this.cancelEvent.bind( this );
		this.setUserAccessFromDisplayListBound =  this.setUserAccessFromDisplayList.bind( this );
		this.setUserAccessFromInstanceBound = this.setUserAccessFromInstance.bind( this );
	}

	,_should: {
		error: {
			test_multiple_register_of_same_view_should_throw_Error: Error
			,test_command_from_stage_should_fail: Error
		}
	}

	,setUp: function()
	{
		this.executed = false;
		this.executedCount = 0;
		this.userAccessFromInstanceCount = 0;
		this.userAccessFromDisplayList = false;
		this.userAccessFromInstance = false;

		this.spriteTestAccess = document.getElementById( "testSprite" );
		this.spriteTestAccess.addEventListener( InvocationCommandList.TEST,  this.setUserAccessFromDisplayListBound );
		this.soma = new soma.core.Core( new Element("testooo") );
		this.soma.addEventListener( InvocationCommandList.TEST, this.setUserAccessFromInstanceBound );
		this.stage = this.soma.stage;
		this.soma.addCommand( InvocationCommandList.TEST, TestCommand );



	}

	,tearDown: function()
	{
		this.spriteTestAccess.removeEventListener( InvocationCommandList.TEST, this.setUserAccessFromDisplayListBound );
		this.soma.removeEventListener( InvocationCommandList.TEST, this.setUserAccessFromInstanceBound );
		this.soma.removeCommand( InvocationCommandList.TEST, TestCommand );
		this.soma.dispose();
		this.soma = null;

	}


	,test_command_from_displayList: function()
	{
		this.spriteTestAccess.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this ) );
		var f = this.defaultCheck();
		if( f !== null )  {
			this.fail( f );
		}
		this.assertTrue( this.executed );
	}



	 /**
	  * the display list dispatches, the framework catches, dispatches a clone and gives the opportunity to wires to
	  * "prevent default" the commandthe display list dispatches, the framework catches,
	  * dispatches a clone and gives the opportunity to wires to "prevent default" the command
	  */
	,test_command_from_displayList_bubbles_false: function()
	{
		this.spriteTestAccess.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this, false ) );
		var f = this.defaultCheck();
		if( f !== null )  {
			this.fail( f );
		}
		this.assertFalse( this.executed );
	}



	,test_command_from_instance: function()
	{
		this.soma.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this ) );
		var f = this.defaultCheck();
		if( f !== null )  {
			this.fail( f );
		}
		this.assertTrue( this.executed );
	}



	,test_command_from_instance_bubbles_false: function()
	{
		this.soma.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this, false ) );
		var f = this.defaultCheck();
		if( f !== null )  {
			this.fail( f );
		}
		this.assertFalse( this.executed );
	}


	,test_command_from_stage: function()
	{
		this.stage.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this ) );
		var f = this.defaultCheck();
		if( f !== null )  {
			this.fail( f );
		}
		this.assertTrue( this.executed );
	}

	,test_command_from_stage_bubbles_false: function()
	{
		this.stage.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this, false ) );
		var f = this.defaultCheck();
		if( f !== null )  {
			this.fail( f );
		}
		this.assertFalse( this.executed );
	}

	,test_cancel_event_dispatched_from_instance: function()
	{
		this.soma.addEventListener( InvocationCommandList.TEST, this.cancelEventBound );
		this.soma.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this ) );
		this.assertFalse( this.executed );
		this.soma.removeEventListener(  InvocationCommandList.TEST, this.cancelEventBound );
	}


	,test_cannot_cancel_event_dispatched_from_instance: function()
	{
		this.soma.addEventListener( InvocationCommandList.TEST, this.cancelEventBound );
		this.soma.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this, true, false ) );
		this.assertTrue( this.executed );
		this.soma.removeEventListener(  InvocationCommandList.TEST, this.cancelEventBound );

	}

	,test_cancel_event_dispatched_from_displaylist: function()
	{
		this.soma.addEventListener( InvocationCommandList.TEST, this.cancelEventBound );
		this.spriteTestAccess.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this ) );
		this.assertFalse( this.executed );
		this.soma.removeEventListener( InvocationCommandList.TEST, this.cancelEventBound );
	}

	,test_cannot_cancel_event_dispatched_from_displaylist: function()
	{
		this.soma.addEventListener( InvocationCommandList.TEST, this.cancelEventBound );
		this.spriteTestAccess.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this, true, false ) );
		this.assertTrue( this.executed );
		// TODO check via hasEventListener if sprite has Listener cancelEventBound
		this.soma.removeEventListener( InvocationCommandList.TEST, this.cancelEventBound );
	}


	,test_cancel_event_dispatched_from_stage: function()
	{
		this.soma.addEventListener( InvocationCommandList.TEST, this.cancelEventBound );
		this.stage.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this )  );
		this.assertFalse( this.executed );
   		this.soma.removeEventListener( InvocationCommandList.TEST, this.cancelEventBound );
	}

	,test_cannot_cancel_event_dispatched_from_stage: function()
	{
 		this.soma.addEventListener( InvocationCommandList.TEST, this.cancelEventBound );
		this.stage.dispatchEvent( new TestEvent( InvocationCommandList.TEST, this, true, false )  );
		this.assertTrue( this.executed );
   		this.soma.removeEventListener( InvocationCommandList.TEST, this.cancelEventBound );
	}


	,test_parallel_command: function()
	{
		this.soma.dispose();
		this.soma = new soma.core.Core( new Element("testooo222") );

		this.soma.addCommand( InvocationCommandList.TEST, TestCommand );
		this.soma.addCommand( InvocationCommandList.PARALLEL, TestParallelCommand );
		this.soma.addModel( EmptyModel.NAME, new EmptyModel( this ) );
		this.soma.dispatchEvent( new TestEvent( InvocationCommandList.PARALLEL ) );
		this.assertEquals( this.executedCount, 5 );
	}

	,_test_async_command: function()
	{
		this.soma.dispose();
		this.soma.addCommand( InvocationCommandList.TEST, TestAsyncCommand );
		this.soma.addEventListener( InvocationCommandList.TEST_ASYNC_COMPLETE);
		//this.wait( this.test_async_command_success.bind(this) );

		// TODO implement async
		//soma.addEventListener(TestEvent.TEST_ASYNC_COMPLETE, Async.asyncHandler(this, testAsyncCommandSuccess, 500, soma, testAsyncCommandFailed), false, 0, true);
		//this.soma.dispatchEvent(new TestEvent(InvocationCommandList.TEST));

	}

	,_test_async_command_fail: function()
	{
		fail("AsyncCommand has not been executed under 500ms");
	}

	,_test_async_command_success: function()
	{
	   this.assertTrue( true );
	}

	/*


	 */

	 ,setToExecuted: function()
	{
		this.executedCount++;
		this.executed = true;
	}

	,setUserAccessFromDisplayList: function( e )
	{
		d("setUserAccessFromDisplayList");
		this.userAccessFromDisplayList = true;
	}

	,setUserAccessFromInstance: function( e )
	{
		d("setUserAccessFromInstance");
		this.userAccessFromInstance = true;
		this.userAccessFromInstanceCount++;
	}

	,cancelEvent: function( e )
	{
 		d("cancelEvent");
		e.preventDefault();
	}

	,defaultCheck: function()
	{
		if ( this.executed && !this.userAccessFromInstance) return "User did not have access to the command from the framework";
		else if ( this.userAccessFromInstanceCount > 1) return "User had access to the command from the framework twice";
		else if ( this.executed && this.userAccessFromDisplayList) return "User had access to the command from the display list";
		else if ( this.executedCount > 1) return "Command has been executed twice";
		return null;
	}

});



